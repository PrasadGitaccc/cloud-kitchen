package com.ck.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.ck.security.MyUserDetailsService;

@SpringBootApplication(exclude = SecurityAutoConfiguration.class)
@ComponentScans({ @ComponentScan("com.ck.controller") })
@EnableJpaRepositories("com.ck.dao")
@EntityScan("com.ck.entity")
public class CloudKichenAppApplication {

    @Bean
    BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

//	@Bean
//	public MyUserDetailsService myUserDetailsService() {
//		return new MyUserDetailsService();
//	}



    @Bean
    UserDetailsService userDetailsService() {
        return new MyUserDetailsService(); // (1)
    }
	
	public static void main(String[] args) {
		SpringApplication.run(CloudKichenAppApplication.class, args);
	}

}
