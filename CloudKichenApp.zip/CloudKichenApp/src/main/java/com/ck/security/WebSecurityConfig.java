package com.ck.security;

public class WebSecurityConfig {

}
