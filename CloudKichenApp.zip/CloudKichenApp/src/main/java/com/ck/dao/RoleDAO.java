package com.ck.dao;

import com.ck.entity.Role;

public interface RoleDAO {

	public Role findByName(String name);
}
