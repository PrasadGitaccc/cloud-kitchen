package com.ck.dao;

import java.util.List;

import com.ck.entity.Product;

public interface ProductDAO {
    public List<Product> findAll();
    public Product findByName(String name);
    public void add(Product product);
    public void update(Product product);
    public void delete(Product product);
}
